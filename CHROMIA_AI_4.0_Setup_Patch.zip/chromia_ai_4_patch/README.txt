CHROMIA AI 4.0 setup patch

Start with CHROMIA-INSTALL.txt. The key first check is the GitHub media URL;
confirm your Chromebook can download the 80.3 MiB model file before forking
and editing the engine repository.

Files:
  models/catalog.json  One-model catalog configured for CHROMIA Core.
  chromia-brand.css    Dark blue/purple CHROMIA theme.
  CHROMIA-INSTALL.txt  Full Chromebook installation and troubleshooting.

This patch does not include the model binary or upstream engine source.
